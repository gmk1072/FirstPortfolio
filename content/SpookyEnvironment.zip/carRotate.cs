﻿using UnityEngine;
using System.Collections;

/// <summary>
/// will rotate the cars which are at either end of the car
/// </summary>
public class carRotate : MonoBehaviour
{
    //fields
    public float rotationSpeed = 175.0f;//the speed at which the cars rotate

    /// <summary>
    /// use this for initialization
    /// unused
    /// </summary>
    void Start()
    {

    }


    /// <summary>
    /// update is called once per frame
    /// rotates the cars 
    /// </summary>
    void Update()
    {
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);//rotates the car at the specified speed around its up axis.
    }
}
