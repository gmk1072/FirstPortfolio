﻿using UnityEngine;
using System.Collections;
/// <summary>
/// will rotate the arm back and forth
/// </summary>
public class armRotate : MonoBehaviour
{

    /// <summary>
    /// Use this for initialization 
    /// unused
    /// </summary>
    void Start()
    {

    }

    /// <summary>
    /// update is called once per frame
    /// will rotate the arm of the irde
    /// </summary>
    void Update()
    {
        float next = 5 * Mathf.Cos(1 * Time.time);// gets the next amount to rotate by
        transform.Rotate(Vector3.right, next);//rotates the arm by the value calculated above about the right axis
    }
}
