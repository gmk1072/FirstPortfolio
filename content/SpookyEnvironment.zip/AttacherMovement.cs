﻿using UnityEngine;
using System.Collections;
/// <summary>
/// moves the attacher
/// the attacher is what connects the arm to the main body
/// it will be moving up and down
/// </summary>
public class AttacherMovement : MonoBehaviour
{
    //fields
    private float initialY;//the initial y position of the attacher
    private float magnitude = 3.07f;//the magnitude to which the attacher will go up and down to
    private float frequency = .75f;//the frequency at which it will go back to its original position

    /// <summary>
    /// use this for initialization
    /// initializes the initialy position
    /// </summary>
    void Start()
    {
        initialY = transform.position.y;
    }

    /// <summary>
    /// update is called once per frame
    /// moves the attacher up and down
    /// </summary>
    void Update()
    {
        float nextY = initialY + magnitude * Mathf.Sin(frequency * Time.time);//gets the next position for the attacher to be at
        transform.position = new Vector3(transform.position.x, nextY, transform.position.z);//sets the position to the y set above
    }
}
