﻿using UnityEngine;
using System.Collections;

/// <summary>
/// its an obstacle
/// </summary>
public class ObstacleScript : MonoBehaviour
{
    public float radius = 2.4f;//the radius of the obstacle
    public float Radius { get { return radius; } }//the accessor for the obsacle's radius
}

