﻿using UnityEngine;
using System.Collections;

public class OpenDoor : MonoBehaviour {

	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider c)
	{
		if (c.tag == "Player") {
			GetComponent<Animator>().SetBool("open",true);
		}
	}

	void OnTriggerExit(Collider c)
	{
		if (c.tag == "Player") {
			GetComponent<Animator>().SetBool("open",false);
		}
	}
}
