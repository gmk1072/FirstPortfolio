﻿using UnityEngine;
using System.Collections;

public class Catapult : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Player")
        {
            if(!GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Shoot"))
            {
                if (Input.GetKeyDown(KeyCode.E))
                {
                    GetComponent<Animator>().SetTrigger("shoot");
                }
            }
            
        }
    }
}
