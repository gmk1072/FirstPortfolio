﻿using UnityEngine;
using System.Collections;

public class UnderWater : MonoBehaviour
{

    public float waterLevel = 10.7f;
    private bool isUnderWater;
    private Color normalColor;
    private Color underwaterColor;
    
    // Use this for initialization
    void Start()
    {
        normalColor = new Color(.5f, .5f, .5f, .5f);
        underwaterColor = new Color(.22f, .65f, .77f, .5f);
    }

    // Update is called once per frame
    void Update()
    {
        if((this.GetComponentInParent<Transform>().transform.position.y < waterLevel)!=isUnderWater)
        {
            isUnderWater = this.GetComponentInParent<Transform>().transform.position.y < waterLevel;
            if(isUnderWater)
            {
                SetUnderWater();
            }
            if(!isUnderWater)
            {
                SetNormal();
            }
        }
    }

    public void SetUnderWater()
    {
        RenderSettings.fogColor = underwaterColor;
        RenderSettings.fogDensity = .03f;
    }
    public void SetNormal()
    {
        RenderSettings.fogColor = normalColor;
        RenderSettings.fogDensity = .002f;
    }
}
